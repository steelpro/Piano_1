﻿using System;
using System.Windows.Forms;

namespace Piano
{
    public partial class PianoBox : Form
    {
        public PianoBox() { InitializeComponent();}
        private void btnSound_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\1.wav");
            player.Play();
        }
        private void button2_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\1.wav");
            player.Play();
        }
        private void button1_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\2.wav");
            player.Play();
        }
        private void button3_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\3.wav");
            player.Play();
        }
        private void button4_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\4.wav");
            player.Play();
        }
        private void button5_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\5.wav");
            player.Play();
        }
        private void button6_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\6.wav");
            player.Play();
        }
        private void button7_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\song.wav");
            player.Play();
        }
        private void button8_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\7.wav");
            player.Play();
        }
        private void button9_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\8.wav");
            player.Play();
        }
        private void button10_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\9.wav");
            player.Play();
        }
        private void button11_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\10.wav");
            player.Play();
        }
        private void button12_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\11.wav");
            player.Play();
        }
        private void button13_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\12.wav");
            player.Play();
        }
        private void button14_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\13.wav");
            player.Play();
        }
        private void button15_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\14.wav");
            player.Play();
        }
        private void button16_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\15.wav");
            player.Play();
        }
        private void button17_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\01.wav");
            player.Play();
        }
        private void button18_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\02.wav");
            player.Play();
        }
        private void button19_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\03.wav");
            player.Play();
        }
        private void button20_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\04.wav");
            player.Play();
        }
        private void button21_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\05.wav");
            player.Play();
        }
        private void button22_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\06.wav");
            player.Play();
        }
        private void button23_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\07.wav");
            player.Play();
        }
        private void button24_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\08.wav");
            player.Play();
        }
        private void button25_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\09.wav");
            player.Play();
        }
        private void button26_Click(object sender, EventArgs e) {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\Zachary\Documents\00.wav");
            player.Play();
        }
        private void button27_Click(object sender, EventArgs e) { Close(); }
    }
}